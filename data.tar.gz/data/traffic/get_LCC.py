import sys
import operator
import getopt
import math
import datetime
from datetime import date
from datetime import datetime
import time
from datetime import timedelta
from collections import deque

def DFS(v, G, C, inc):
    C[v] = 1
    inc[v] = 1

    for u in G[v]:
        if u in G and v in G[u]:
	    if u not in C:
	        DFS(u, G, C, inc)

def BFS(v, G, C, inc, max_vert):
    q = deque([v])
    C[v] = 1
    inc[v] = 1

    while len(q) > 0 and len(C) < max_vert:
        u = q.popleft()
	#print "len(C) = %d, len(q) = %d, max = %d" % (len(C), len(q), max_vert)
    
        for z in G[u]:
            if z not in C:
                q.append(z)
		C[z] = 1
                inc[z] = 1

input_graph_file_name = sys.argv[1]
output_file_name = sys.argv[2]
max_num_vertices = int(sys.argv[3])

input_graph_file = open(input_graph_file_name, 'r')

graph = {}

for line in input_graph_file:
    line = line.rstrip()
    vec = line.rsplit(',')

    vertex_one = vec[0]
    vertex_two = vec[1]

    if vertex_one not in graph:
        graph[vertex_one] = {}

    graph[vertex_one][vertex_two] = 1

input_graph_file.close()

included = {}
components = []
largest = 0
size_largest = 0

sys.setrecursionlimit(len(graph)+1)

for vertex in graph:
    if vertex not in included:
        components.append({})
	
	if max_num_vertices < 0:
	    DFS(vertex, graph, components[-1], included)
	else:
	    BFS(vertex, graph, components[-1], included, max_num_vertices)
        
	if len(components[-1]) >= size_largest:
            size_largest = len(components[-1])
	    largest = len(components) - 1

input_graph_file = open(input_graph_file_name, 'r')
output_file = open(output_file_name, 'w')

for vertex in components[largest]:
    output_file.write(vertex+"\n")

output_file.close()


