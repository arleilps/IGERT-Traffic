import sys
import operator
import getopt
import math
import datetime
from datetime import date
from datetime import datetime
import time
from datetime import timedelta

input_data_file_name = "traffic.data"
output_data_file_name = "new_traffic.data"

input_graph_file_name = "traffic.graph"
output_graph_file_name = "new_traffic.graph"

edges = {}

input_graph_file = open(input_graph_file_name, 'r')

for line in input_graph_file:
    line = line.rstrip()
    vec = line.rsplit(',')

    vertex_one = vec[0]
    vertex_two = vec[1]

    if vertex_one not in edges:
        edges[vertex_one] = {}

    edges[vertex_one][vertex_two] = 0

input_graph_file.close()

to_be_delected_v = []

for v in edges:
    to_be_delected_u = []
    for u in edges[v]:
        if u not in edges or v not in edges[u]:
	    to_be_delected_u.append(u)
    
    for u in to_be_delected_u:
        del edges[v][u]
    
    if len(edges[v]) == 0:
        to_be_delected_v.append(v)

for v in to_be_delected_v:
    del edges[v] 

input_graph_file = open(input_graph_file_name, 'r')
output_graph_file = open(output_graph_file_name, 'w')

for line in input_graph_file:
    line = line.rstrip()
    vec = line.rsplit(',')

    vertex_one = vec[0]
    vertex_two = vec[1]
    
    if vertex_one in edges and vertex_two in edges and vertex_two in edges[vertex_one] and edges[vertex_one][vertex_two] == 0:
        output_graph_file.write(line+"\n")
	edges[vertex_one][vertex_two] = 1
        
input_graph_file.close()
output_graph_file.close()

input_data_file = open(input_data_file_name, 'r')
output_data_file = open(output_data_file_name, 'w')

for line in input_data_file:
    line = line.rstrip()
    vec = line.rsplit(',')
    
    vertex = vec[0]
    
    if vertex in edges:
        output_data_file.write(line+"\n")

output_data_file.close()
input_data_file.close()

