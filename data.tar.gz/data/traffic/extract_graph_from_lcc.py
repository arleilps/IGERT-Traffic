import sys

input_graph_file_name = sys.argv[1]
input_lcc_file_name = sys.argv[2]

input_lcc_file = open(input_lcc_file_name, 'r')
lcc = {}

for line in input_lcc_file:
    vertex = line.rstrip()

    lcc[vertex] = 1

input_lcc_file.close()


input_graph_file = open(input_graph_file_name, 'r')

for line in input_graph_file:
    line = line.rstrip()
    vec = line.rsplit(',')
    
    vertex_one = vec[0]
    vertex_two = vec[1]

    if vertex_one in lcc and vertex_two in lcc:
        print line

input_graph_file.close()
