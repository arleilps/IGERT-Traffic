import sys
import operator
import getopt
import math
import datetime
from datetime import date
from datetime import datetime
import time
from datetime import timedelta

input_graph_file_name = "new_traffic.graph"
output_graph_file_name = "new_new_traffic.graph"

edges = {}

input_graph_file = open(input_graph_file_name, 'r')

for line in input_graph_file:
    line = line.rstrip()
    vec = line.rsplit(',')

    if vec[0] < vec[1]:
        vertex_one = vec[0]
        vertex_two = vec[1]
    else:
        vertex_one = vec[1]
        vertex_two = vec[0]

    if vertex_one not in edges:
        edges[vertex_one] = {}

    edges[vertex_one][vertex_two] = 0

input_graph_file.close()

input_graph_file = open(input_graph_file_name, 'r')
output_graph_file = open(output_graph_file_name, 'w')

for line in input_graph_file:
    line = line.rstrip()
    vec = line.rsplit(',')

    if vec[0] < vec[1]:
        vertex_one = vec[0]
        vertex_two = vec[1]
    else:
        vertex_one = vec[1]
        vertex_two = vec[0]

    if vertex_one not in edges:
        edges[vertex_one] = {}

    if edges[vertex_one][vertex_two] == 0:
        output_graph_file.write(line+"\n")
	edges[vertex_one][vertex_two] = 1
        
output_graph_file.close()
input_graph_file.close()

